//package org.example;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.fasterxml.jackson.core.type.TypeReference;
//
//import java.io.File;
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.List;
//
//public class JsonFileHandler {
//
//    private static final ObjectMapper objectMapper = new ObjectMapper();
//
//    public static void savePastries(List<Pastry> pastries, String filename) {
//        try {
//            objectMapper.writeValue(new File(filename), pastries);
//            System.out.println("Pastries saved successfully to " + filename);
//        } catch (IOException e) {
//            System.out.println("Failed to save pastries: " + e.getMessage());
//        }
//    }
//
//    public static List<Pastry> loadPastries(String filename) {
//        try {
//            return objectMapper.readValue(new File(filename), new TypeReference<List<Pastry>>() {});
//        } catch (IOException e) {
//            System.out.println("Failed to load pastries: " + e.getMessage());
//            return null;
//        }
//    }
//
//    public static void saveIngredients(List<Ingredient> ingredients, String filename) {
//        try {
//            objectMapper.writeValue(new File(filename), ingredients);
//            System.out.println("Ingredients saved successfully to " + filename);
//        } catch (IOException e) {
//            System.out.println("Failed to save ingredients: " + e.getMessage());
//        }
//    }
//
//    public static List<Ingredient> loadIngredients(String filename) {
//        try {
//            return objectMapper.readValue(new File(filename), new TypeReference<List<Ingredient>>() {});
//        } catch (IOException e) {
//            System.out.println("Failed to load ingredients: " + e.getMessage());
//            return null;
//        }
//    }
//
//    public static void saveOrders(List<Order> orders, String filename) {
//        try {
//            objectMapper.writeValue(new File(filename), orders);
//            System.out.println("Orders saved successfully to " + filename);
//        } catch (IOException e) {
//            System.out.println("Failed to save orders: " + e.getMessage());
//        }
//    }
//
//    public static List<Order> loadOrders(String filename) {
//        try {
//            return objectMapper.readValue(new File(filename), new TypeReference<List<Order>>() {});
//        } catch (IOException e) {
//            System.out.println("Failed to load orders: " + e.getMessage());
//            return new ArrayList<>(); // Return empty list on failure
//        }
//    }
//
//}
