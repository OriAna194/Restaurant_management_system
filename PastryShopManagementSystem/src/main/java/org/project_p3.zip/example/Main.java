package org.example;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.fasterxml.jackson.databind.JsonMappingException;
import java.io.FileNotFoundException;

import java.util.InputMismatchException;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static final Scanner scanner = new Scanner(System.in);
    private static final ChefActions chef = new PastryChef("Gordon Ramsay");
    private static final List<Order> orders = new ArrayList<>();
    private static final String PASTRIES_FILE = "pastries.json";
    private static final String INGREDIENTS_FILE = "ingredients.json";
    private static final String ORDERS_FILE = "orders.json";

    public static void main(String[] args) {
        loadData();
        boolean running = true;

        while (running) {
            System.out.println("\nOptions: ");
            System.out.println("1. Create a new recipe");
            System.out.println("2. Create a new order");
            System.out.println("3. Add pastry to an order");
            System.out.println("4. View all orders status");
            System.out.println("5. Update individual pastry status in an order");
            System.out.println("6. View stored recipes");
            System.out.println("7. Save and Exit");

            int choice = getIntInput("Choose an option: ", 1, 7);


            switch (choice) {
                case 1:
                    try {
                        Recipe newRecipe = chef.createRecipe(scanner);  //Call through the interface
                        newRecipe.displayRecipe();
                    } catch (DuplicateEntryException e) {
                        System.out.println(e.getMessage());
                        System.out.println("Try a different name or cancel the action.");
                    }
                    break;
                case 2:
                    createNewOrder();
                    break;
                case 3:
                    addPastryToOrder();
                    break;
                case 4:
                    viewAllOrdersStatus();
                    break;
                case 5:
                    updateIndividualPastryStatus();
                    break;
                case 6:
                    viewAndSelectRecipe();
                    break;
                case 7:
                    saveData();
                    System.out.println("Exiting application.");
                    running = false;
                    break;
                default:
                    System.out.println("Invalid option, please try again.");
            }
        }
        scanner.close();
    }

    private static void createNewOrder() {
        Order newOrder = new Order();
        orders.add(newOrder);
        System.out.println("New order created. Order ID: " + orders.size());
    }

    private static void addPastryToOrder() {
        if (orders.isEmpty()) {
            System.out.println("No orders available. Please create an order first.");
            return;
        }


        int orderId = getIntInput("Enter the order ID to add a pastry to: ", 1, orders.size());
        String pastryName = getNonEmptyString("Enter the name of the pastry to add to the order: ");


        try {
            Pastry pastry = searchForPastry(pastryName);
            orders.get(orderId - 1).addPastry(pastry);
            System.out.println("Pastry added to Order " + orderId + ".");
        } catch (PastryNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static Pastry searchForPastry(String name) throws PastryNotFoundException {
        for (Recipe recipe : chef.getRecipes()) {
            if (recipe.getPastry().getName().equalsIgnoreCase(name)) {
                return recipe.getPastry();
            }
        }
        throw new PastryNotFoundException("Pastry with name " + name + " not found.");
    }

    private static void updateIndividualPastryStatus() {
        if (orders.isEmpty()) {
            System.out.println("No orders available. Please create an order first.");
            return;
        }

        // Validating order ID input
        int orderId = getIntInput("Enter the order ID to update a pastry in: ", 1, orders.size());
        Order selectedOrder = orders.get(orderId - 1);

        // Validating pastry name by checking if it exists in the order
        Pastry pastryToUpdate = null;
        while (pastryToUpdate == null) {
            String pastryName = getNonEmptyString("Enter the name of the pastry to update: ");


            for (Pastry pastry : selectedOrder.getPastries()) {
                if (pastry.getName().equalsIgnoreCase(pastryName)) {
                    pastryToUpdate = pastry;
                    break;
                }
            }


            if (pastryToUpdate == null) {
                System.out.println("Pastry not found in this order. Please enter a valid pastry name.");
            }
        }

        // Validating the preparation status and update the pastry status
        PreparationStatusEnum status = getValidStatus("Enter new status for the pastry (NOT_STARTED, IN_PROGRESS, READY): ");
        pastryToUpdate.updatePreparationStatus(status);
        System.out.println("Status updated successfully.");
    }


    private static void viewAllOrdersStatus() {
        if (orders.isEmpty()) {
            System.out.println("No orders available.");
            return;
        }

        int orderCount = 1;
        for (Order order : orders) {
            System.out.println("Order " + orderCount + ":");
            for (Pastry pastry : order.getPastries()) {
                System.out.println("Status for " + pastry.getName() + ": " + pastry.getPreparationStatus());
            }
            orderCount++;
        }
    }


    private static void viewAndSelectRecipe() {

        if (chef.getRecipes().isEmpty()) {
            System.out.println("No recipes available.");
            return;
        }

        System.out.println("Stored Recipes:");
        int index = 1;
        for (Recipe recipe : chef.getRecipes()) {
            System.out.println(index + ". " + recipe.getPastry().getName() + " (" + recipe.getPastry().getType() + ")");
            index++;
        }

        int choice = getIntInput("Enter the recipe number to view its full details or '0' to go back: ", 0, chef.getRecipes().size());

        if (choice == 0) {
            return;
        }


        Recipe selectedRecipe = chef.getRecipes().get(choice - 1);
        selectedRecipe.displayRecipe();
    }


    // INPUT VALIDATION METHODS

    // input validation for integer within a specified range
    private static int getIntInput(String prompt, int min, int max) {
        int input;
        while (true) {
            try {
                System.out.print(prompt);
                input = Integer.parseInt(scanner.nextLine());
                if (input >= min && input <= max) {
                    return input;
                } else {
                    System.out.println("Please enter a number between " + min + " and " + max + ".");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid integer.");
            }
        }
    }

    // input validation for a non-empty string
    private static String getNonEmptyString(String prompt) {
        String input;
        do {
            System.out.print(prompt);
            input = scanner.nextLine().trim();
            if (input.isEmpty()) {
                System.out.println("Input cannot be empty. Please try again.");
            }
        } while (input.isEmpty());
        return input;
    }

    // input validation for valid PreparationStatusEnum value
    private static PreparationStatusEnum getValidStatus(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return PreparationStatusEnum.valueOf(scanner.nextLine().trim().toUpperCase());
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid status. Please choose from: NOT_STARTED, IN_PROGRESS, READY.");
            }
        }
    }





    private static void loadData() {
        ObjectMapper mapper = new ObjectMapper();

        try {
            // Load Recipes
            File pastriesFile = new File(PASTRIES_FILE);
            if (pastriesFile.exists()) {
                System.out.println("Loading previous pastries...");
                List<Recipe> recipes = mapper.readValue(pastriesFile, new TypeReference<List<Recipe>>() {});
                ((PastryChef) chef).setRecipes(recipes);
            } else {
                System.out.println("Pastries file not found. Loading default or empty recipe list.");
            }

            // Load Ingredients
            File ingredientsFile = new File(INGREDIENTS_FILE);
            if (ingredientsFile.exists()) {
                System.out.println("Loading previous ingredients...");
                List<Ingredient> ingredients = mapper.readValue(ingredientsFile, new TypeReference<List<Ingredient>>() {});
                ((PastryChef) chef).setIngredients(ingredients);
            } else {
                System.out.println("Ingredients file not found. Proceeding without ingredient data.");
            }

            // Load Orders
            File ordersFile = new File(ORDERS_FILE);
            if (ordersFile.exists()) {
                System.out.println("Loading previous orders...");
                List<Order> loadedOrders = mapper.readValue(ordersFile, new TypeReference<List<Order>>() {});
                orders.addAll(loadedOrders);
            } else {
                System.out.println("Orders file not found. Starting with no existing orders.");
            }
        } catch (FileNotFoundException e) {
            System.out.println("A required data file could not be found: " + e.getMessage());
        } catch (JsonMappingException e) {
            System.out.println("Error in data format: Please check the file contents and try again.");
        } catch (IOException e) {
            System.out.println("Failed to load previous session due to an unexpected error: " + e.getMessage());
        }
    }

    private static void saveData() {
        ObjectMapper mapper = new ObjectMapper();

        try {
            // Save Recipes
            mapper.writeValue(new File(PASTRIES_FILE), chef.getRecipes());  //interface method
            System.out.println("Recipes saved to " + PASTRIES_FILE);

            // Save Ingredients
            mapper.writeValue(new File(INGREDIENTS_FILE), chef.getIngredients());  //interface method
            System.out.println("Ingredients saved to " + INGREDIENTS_FILE);

            // Save Orders
            mapper.writeValue(new File(ORDERS_FILE), orders);
            System.out.println("Orders saved to " + ORDERS_FILE);

            System.out.println("Session saved.");
        } catch (FileNotFoundException e) {
            System.out.println("Could not find file to save data: " + e.getMessage());
        } catch (JsonMappingException e) {
            System.out.println("Data format error: Could not save session.");
        } catch (IOException e) {
            System.out.println("Failed to save data due to an unexpected error: " + e.getMessage());
        }
    }
}
