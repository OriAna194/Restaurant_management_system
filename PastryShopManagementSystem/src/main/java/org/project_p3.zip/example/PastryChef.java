package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PastryChef implements ChefActions{

    private String name;
    private List<Recipe> recipes;
    private List<Ingredient> ingredients;

    public PastryChef(String name) {
        this.name = name;
        this.recipes = new ArrayList<>();
        this.ingredients = new ArrayList<>();
    }

    @Override
    public Recipe createRecipe(Scanner scanner) throws DuplicateEntryException{
        System.out.print("Enter pastry name: ");
        String pastryName = scanner.nextLine();

        //Check for duplicate recipe names
        for (Recipe recipe : recipes) {
            if (recipe.getPastry().getName().equalsIgnoreCase(pastryName)) {
                throw new DuplicateEntryException("A recipe with the name '" + pastryName + "' already exists.");
            }
        }

        System.out.print("Enter pastry type: ");
        String pastryType = scanner.nextLine();


        Pastry pastry = new Pastry(pastryName, pastryType);


        List<Ingredient> recipeIngredients = new ArrayList<>();
        boolean addingIngredients = true;

        while (addingIngredients) {
            System.out.print("Enter ingredient name (or 'done' to finish): ");
            String ingredientName = scanner.nextLine();

            if (ingredientName.equalsIgnoreCase("done")) {
                addingIngredients = false;
            } else {
                System.out.print("Enter quantity for " + ingredientName + ": ");
                double quantity = Double.parseDouble(scanner.nextLine());

                System.out.print("Enter unit for " + ingredientName + ": ");
                String unit = scanner.nextLine();

                Ingredient ingredient = new Ingredient(ingredientName, quantity, unit);
                recipeIngredients.add(ingredient);
                ingredients.add(ingredient);
            }
        }

        System.out.print("Enter instructions for the recipe: ");
        String instructions = scanner.nextLine();

        Recipe recipe = new Recipe(pastry, recipeIngredients, instructions);
        recipes.add(recipe);
        return recipe;
    }

    public void addRecipe(Recipe recipe) {
        recipes.add(recipe);
    }

    @Override
    public List<Recipe> getRecipes() {
        return recipes;
    }

    public void setRecipes(List<Recipe> recipes) {
        this.recipes = recipes;
    }

    @Override
    public List<Ingredient> getIngredients() {
        return ingredients;
    }

    public void setIngredients(List<Ingredient> ingredients) {
        this.ingredients = ingredients;
    }
}
